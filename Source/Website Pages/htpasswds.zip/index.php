<!-- index.php
     the defalut page
     has a brief description of what KeyFree is and how to use it -->

<!DOCTYPE html>
<html>
	<head>
		<?php include 'style.php';?>
	</head>
	
	
	<body>
	
		<h1 class="text">Welcome to Key-Free!</h1>
		<br><br>
		<p class="text">Key-Free is a revolutionary product that securely stores your data on a device you control.  </p>
		<br><br> 	
		<p class="text">Here is the current progress of the Key-Free system: <br>
			<img src="Photo_2.jpg" width="560" height="315" title="12/5/2014" alt="Logo of a company" /></p>

                        
		<br><br>
		<p class="text">Demo Video<br>
			<iframe width="560" height="315" src="https://www.youtube.com/embed/OAqbk4DVV5Q" frameborder="0" allowfullscreen></iframe></p>
	</body>
</html>