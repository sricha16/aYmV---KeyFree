<!-- help.php
     Provides help for how to use KeyFree
     Includes basic instructions, FAQ and A, and a way to receive further help -->

<!DOCTYPE HTML>
<html>
	<head>
		<?php include 'style.php';?>

		<p class="text">i can has?</p><br>
	</head>
</html>

