<!-- aboutus.php
     Description of KeyFree
     Includes what we do and who we are -->

<!DOCTYPE HTML>
<html>
	<head>
		<?php include 'style.php';?>

		<p class = "text"> 
			<strong> <font size = "4"> What is Key-Free? </font> </strong> 
			<br>
			 Key-Free is a secure and reliable way to store passwords or any sensitive information that is hard to remember but shouldn't be written down. It is a compact micro-controller with an audio adapter that communicates via the headphone jack to store information on a micro SD card. Informaton is accessed and stored through a web portal that utilizes JavaScript to encrypt the sensitive information. That way, the user only has to remember one key, rather than all of their passwords. This can also allow users to use more secure passwords, that are longer and composed of random characters, and not worry about forgetting them. Basically, it is one password to rule them all!</p><br>
			 
		<p class="text"> 
		<strong> <font size = "4"> Contact us! </font> </strong> <br>
		stand@key-free.co
		</p><br>
	</head>
</html>